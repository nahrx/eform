#!/usr/bin/env node
/**
 * Validator instrumen kuesioner v1.1 — struktural (JSON Schema/AJV) + semantik.
 *
 *   node validate.mjs <instrumen.json> [schema.json]
 *
 * Butuh: npm i ajv ajv-formats
 *
 * Struktur v1.1: pages -> block -> section -> roster/field.
 * Menutup yang TIDAK bisa divalidasi JSON Schema:
 *   1. Keunikan global 'name'.
 *   2. Resolusi referensi: optionsRef, optionsFilterBy, countFrom, skipTo, to, dan ${...} (termasuk ${roster.field}).
 *   3. Sintaks ekspresi — memakai parser yang sama persis seperti eForm - Builder.
 */

import { readFileSync } from "node:fs";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";

/* ===================== expression parser (sinkron dgn builder) ===================== */
const Expr = (function () {
  const FUNCS = new Set(["isempty","notempty","len","count","sum","avg","min","max","in","today","age","regex","if","number","round","abs","floor","ceil","contains","upper","lower","trim"]);
  function tokenize(src) {
    const t = []; let i = 0; const n = src.length; const id = c => /[A-Za-z0-9_]/.test(c);
    while (i < n) {
      let c = src[i];
      if (c === " " || c === "\t" || c === "\n" || c === "\r") { i++; continue; }
      if (c === "$" && src[i + 1] === "{") { let j = i + 2, s = ""; while (j < n && src[j] !== "}") s += src[j++]; if (src[j] !== "}") throw new Error("${ } tidak ditutup"); i = j + 1; t.push({ t: "ref", v: s.trim() }); continue; }
      if (c === "'" || c === '"') { const q = c; let j = i + 1, s = ""; while (j < n && src[j] !== q) { if (src[j] === "\\") { s += src[j + 1]; j += 2; } else s += src[j++]; } if (src[j] !== q) throw new Error("teks tidak ditutup"); i = j + 1; t.push({ t: "str", v: s }); continue; }
      if ((c >= "0" && c <= "9") || (c === "." && src[i + 1] >= "0" && src[i + 1] <= "9")) { let j = i, s = ""; while (j < n && ((src[j] >= "0" && src[j] <= "9") || src[j] === ".")) s += src[j++]; i = j; t.push({ t: "num", v: parseFloat(s) }); continue; }
      if (/[A-Za-z_]/.test(c)) { let j = i, s = ""; while (j < n && id(src[j])) s += src[j++]; i = j; t.push({ t: (s === "true" || s === "false") ? "bool" : (s === "null" ? "null" : "id"), v: s }); continue; }
      const two = src.substr(i, 2);
      if (["==","!=","<=",">=","&&","||"].includes(two)) { t.push({ t: "op", v: two }); i += 2; continue; }
      if ("+-*/%<>!".includes(c)) { t.push({ t: "op", v: c }); i++; continue; }
      if (c === "(") { t.push({ t: "lp" }); i++; continue; }
      if (c === ")") { t.push({ t: "rp" }); i++; continue; }
      if (c === "[") { t.push({ t: "lb" }); i++; continue; }
      if (c === "]") { t.push({ t: "rb" }); i++; continue; }
      if (c === ",") { t.push({ t: "comma" }); i++; continue; }
      throw new Error("karakter tak dikenal: " + c);
    }
    return t;
  }
  function parse(src) {
    const toks = tokenize(src); let p = 0;
    const peek = () => toks[p], next = () => toks[p++];
    const expect = k => { if (!toks[p] || toks[p].t !== k) throw new Error("diharapkan '" + k + "'"); return toks[p++]; };
    const refs = [];
    function or() { let l = and(); while (peek() && peek().t === "op" && peek().v === "||") { next(); l = { l, r: and() }; } return l; }
    function and() { let l = eq(); while (peek() && peek().t === "op" && peek().v === "&&") { next(); l = { l, r: eq() }; } return l; }
    function eq() { let l = cmp(); while (peek() && peek().t === "op" && (peek().v === "==" || peek().v === "!=")) { next(); l = { l, r: cmp() }; } return l; }
    function cmp() { let l = add(); while (peek() && peek().t === "op" && ["<","<=",">",">="].includes(peek().v)) { next(); l = { l, r: add() }; } return l; }
    function add() { let l = mul(); while (peek() && peek().t === "op" && (peek().v === "+" || peek().v === "-")) { next(); l = { l, r: mul() }; } return l; }
    function mul() { let l = un(); while (peek() && peek().t === "op" && ["*","/","%"].includes(peek().v)) { next(); l = { l, r: un() }; } return l; }
    function un() { if (peek() && peek().t === "op" && (peek().v === "!" || peek().v === "-")) { next(); return un(); } return prim(); }
    function prim() {
      const k = peek(); if (!k) throw new Error("ekspresi terpotong");
      if (k.t === "num" || k.t === "str" || k.t === "bool" || k.t === "null") { next(); return {}; }
      if (k.t === "ref") { next(); refs.push(k.v); return {}; }
      if (k.t === "lp") { next(); const e = or(); expect("rp"); return e; }
      if (k.t === "lb") { next(); if (peek() && peek().t !== "rb") { or(); while (peek() && peek().t === "comma") { next(); or(); } } expect("rb"); return {}; }
      if (k.t === "id") {
        next();
        if (peek() && peek().t === "lp") { if (!FUNCS.has(k.v.toLowerCase())) throw new Error("fungsi tak dikenal: " + k.v); next(); if (peek() && peek().t !== "rp") { or(); while (peek() && peek().t === "comma") { next(); or(); } } expect("rp"); return {}; }
        throw new Error("pakai ${...} untuk merujuk field, bukan '" + k.v + "'");
      }
      throw new Error("token tak terduga");
    }
    or(); if (p < toks.length) throw new Error("ada token sisa di akhir");
    return { refs };
  }
  return { parse };
})();

/* ===================== load ===================== */
const [, , instrumentPath, schemaPath = "kuesioner.schema.json"] = process.argv;
if (!instrumentPath) { console.error("Usage: node validate.mjs <instrumen.json> [schema.json]"); process.exit(2); }
const schema = JSON.parse(readFileSync(schemaPath, "utf8"));
const inst = JSON.parse(readFileSync(instrumentPath, "utf8"));

const errors = [], warnings = [];
const err = (path, msg) => errors.push({ path, msg });
const warn = (path, msg) => warnings.push({ path, msg });

/* ===================== 1) struktural via AJV ===================== */
const ajv = new Ajv2020({ allErrors: true, strict: false });
addFormats(ajv);
const validate = ajv.compile(schema);
if (!validate(inst)) {
  for (const e of validate.errors) {
    const extra = e.params && Object.keys(e.params).length ? " " + JSON.stringify(e.params) : "";
    err(e.instancePath || "/", `${e.message}${extra}`);
  }
}

/* ===================== kumpulkan simpul ===================== */
const names = new Map();          // name -> [path]
const fields = new Set();         // field names
const containers = new Set();     // page/block/section/roster names
const exprs = [];                 // { path, expr }
const refs = [];                  // { path, kind: table|field|nav, val }
const EK = ["visibleWhen", "enableWhen", "requiredWhen", "calculate"];
const see = (name, path) => { if (!names.has(name)) names.set(name, []); names.get(name).push(path); };

function walk(node, base) {
  const p = `${base}/${node.name || node.kind || "?"}`;
  if (node.kind === "field") {
    if (node.name) { fields.add(node.name); see(node.name, p); }
    EK.forEach(k => { if (notEmpty(node[k])) exprs.push({ path: `${p}.${k}`, expr: node[k] }); });
    if (notEmpty(node.optionsRef)) refs.push({ path: `${p}.optionsRef`, kind: "table", val: node.optionsRef });
    if (notEmpty(node.optionsFilterBy)) refs.push({ path: `${p}.optionsFilterBy`, kind: "field", val: node.optionsFilterBy });
    (node.validations || []).forEach((v, j) => { if (notEmpty(v.test)) exprs.push({ path: `${p}.validations[${j}].test`, expr: v.test }); });
    (node.options || []).forEach((o, j) => { if (notEmpty(o.skipTo)) refs.push({ path: `${p}.options[${j}].skipTo`, kind: "nav", val: o.skipTo }); if (notEmpty(o.visibleWhen)) exprs.push({ path: `${p}.options[${j}].visibleWhen`, expr: o.visibleWhen }); });
    (node.skips || []).forEach((s, j) => { if (notEmpty(s.to)) refs.push({ path: `${p}.skips[${j}].to`, kind: "nav", val: s.to }); if (notEmpty(s.when)) exprs.push({ path: `${p}.skips[${j}].when`, expr: s.when }); });
  } else {
    if (node.name) { containers.add(node.name); see(node.name, p); }
    if (node.kind === "roster" && notEmpty(node.countFrom)) refs.push({ path: `${p}.countFrom`, kind: "field", val: node.countFrom });
    if (notEmpty(node.visibleWhen)) exprs.push({ path: `${p}.visibleWhen`, expr: node.visibleWhen });
    (node.components || []).forEach(c => walk(c, p));
  }
}
function notEmpty(v) { return v !== undefined && v !== null && v !== ""; }

(inst.pages || []).forEach(pg => walk(pg, ""));
(inst.validations || []).forEach((v, i) => { if (notEmpty(v.test)) exprs.push({ path: `validations[${i}].test`, expr: v.test }); });

/* ===================== 2) keunikan name ===================== */
for (const [name, ps] of names) if (ps.length > 1) err(name, `name '${name}' dipakai ${ps.length}×: ${ps.join("  ,  ")}`);

/* ===================== 3) resolusi referensi ===================== */
const tables = new Set(Object.keys(inst.referenceData || {}));
const navTargets = new Set([...fields, ...containers, "__end", "__next", "__prev"]);
for (const r of refs) {
  if (r.kind === "table" && !tables.has(r.val)) err(r.path, `optionsRef '${r.val}' tidak ada di referenceData`);
  if (r.kind === "field" && !fields.has(r.val)) err(r.path, `'${r.val}' bukan field yang ada`);
  if (r.kind === "nav" && !navTargets.has(r.val)) err(r.path, `target lompatan '${r.val}' tidak ditemukan`);
}

/* ===================== 4) sintaks ekspresi + referensi di dalamnya ===================== */
for (const { path, expr } of exprs) {
  let parsed;
  try { parsed = Expr.parse(expr); }
  catch (e) { err(path, `ekspresi tidak valid: ${e.message} — "${expr}"`); continue; }
  for (const ref of parsed.refs) {
    const base = ref.split(/[.\[]/)[0].trim();
    if (!base || base.startsWith("__")) continue;
    if (!fields.has(base) && !containers.has(base)) err(path, `ekspresi merujuk '${base}' yang tidak ada`);
  }
}

/* ===================== 5) i18n ===================== */
const locales = new Set(inst.locales || []);
if (inst.defaultLocale && locales.size && !locales.has(inst.defaultLocale)) warn("defaultLocale", `locale utama '${inst.defaultLocale}' tidak ada di locales [${[...locales].join(", ")}]`);

/* ===================== laporan ===================== */
if (warnings.length) { console.log(`\n⚠️  ${warnings.length} warning:`); warnings.forEach(w => console.log(`  - [${w.path}] ${w.msg}`)); }
if (errors.length) { console.log(`\n❌ ${errors.length} error:`); errors.forEach(e => console.log(`  - [${e.path}] ${e.msg}`)); }
const ok = errors.length === 0;
console.log(ok
  ? `\n✅ ${instrumentPath} VALID — struktural + semantik (${fields.size} field, ${containers.size} container)`
  : `\n❌ ${instrumentPath} TIDAK VALID — ${errors.length} error`);
process.exit(ok ? 0 : 1);
