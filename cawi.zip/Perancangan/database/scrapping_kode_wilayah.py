import requests
import csv
import time

BASE_URL = "https://sig.bps.go.id/rest-bridging/getwilayah"
PERIODE = "2025_2.2025"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/137.0.0.0 Safari/537.36"
    )
}

records = []


def get_wilayah(level, parent):
    params = {
        "level": level,
        "parent": parent,
        "periode_merge": PERIODE
    }

    response = requests.get(
        BASE_URL,
        params=params,
        headers=HEADERS,
        timeout=60
    )

    response.raise_for_status()

    try:
        return response.json()
    except Exception:
        print("\nGagal parsing JSON")
        print("URL:", response.url)
        print("Status:", response.status_code)
        print(response.text[:1000])
        raise


def clean_nama_kabupaten_kota(nama):
    nama_upper = nama.upper()

    if nama_upper.startswith("KABUPATEN "):
        return nama[11:].strip()

    if nama_upper.startswith("KOTA "):
        return nama[5:].strip()

    return nama


def get_level_kabupaten_kota(nama):
    nama_upper = nama.upper()

    if nama_upper.startswith("KOTA "):
        return "kota"

    return "kabupaten"


def escape_sql(value):
    if value is None:
        return ""

    return str(value).replace("'", "''")


print("===================================")
print("MENGAMBIL DATA WILAYAH INDONESIA")
print("===================================\n")

# =====================================================
# PROVINSI
# =====================================================

provinsi_list = get_wilayah(
    level="provinsi",
    parent="0"
)

print(f"Jumlah provinsi: {len(provinsi_list)}\n")

for provinsi in provinsi_list:

    kode_prov = provinsi["kode_bps"]
    nama_prov = provinsi["nama_dagri"]

    print(f"PROVINSI : {nama_prov}")

    records.append({
        "kode_wilayah": kode_prov,
        "nama_wilayah": nama_prov,
        "level": "provinsi",
        "parent_kode_wilayah": None
    })

    try:

        # =================================================
        # KABUPATEN / KOTA
        # =================================================

        kabupaten_list = get_wilayah(
            level="kabupaten",
            parent=kode_prov
        )

        print(
            f"  Kabupaten/Kota : "
            f"{len(kabupaten_list)}"
        )

        for kab in kabupaten_list:

            kode_kab = kab["kode_bps"]
            nama_kab = kab["nama_dagri"]

            records.append({
                "kode_wilayah": kode_kab,
                "nama_wilayah": clean_nama_kabupaten_kota(
                    nama_kab
                ),
                "level": get_level_kabupaten_kota(
                    nama_kab
                ),
                "parent_kode_wilayah": kode_prov
            })

            try:

                # =============================================
                # KECAMATAN
                # =============================================

                kecamatan_list = get_wilayah(
                    level="kecamatan",
                    parent=kode_kab
                )

                print(
                    f"    {nama_kab} : "
                    f"{len(kecamatan_list)} kecamatan"
                )

                for kec in kecamatan_list:

                    kode_kec = kec["kode_bps"]
                    nama_kec = kec["nama_dagri"]

                    records.append({
                        "kode_wilayah": kode_kec,
                        "nama_wilayah": nama_kec,
                        "level": "kecamatan",
                        "parent_kode_wilayah": kode_kab
                    })

                    try:

                        # =====================================
                        # DESA / KELURAHAN
                        # =====================================

                        desa_list = get_wilayah(
                            level="desa",
                            parent=kode_kec
                        )

                        for desa in desa_list:

                            records.append({
                                "kode_wilayah": desa["kode_bps"],
                                "nama_wilayah": desa["nama_dagri"],
                                "level": "desa",
                                "parent_kode_wilayah": kode_kec
                            })

                        print(
                            f"      {nama_kec} : "
                            f"{len(desa_list)} desa"
                        )

                        time.sleep(0.05)

                    except Exception as e:
                        print(
                            f"ERROR DESA "
                            f"{kode_kec}: {e}"
                        )

                time.sleep(0.1)

            except Exception as e:
                print(
                    f"ERROR KECAMATAN "
                    f"{kode_kab}: {e}"
                )

        time.sleep(0.2)

    except Exception as e:
        print(
            f"ERROR KABUPATEN "
            f"{kode_prov}: {e}"
        )

print("\n===================================")
print(f"TOTAL RECORD : {len(records)}")
print("===================================\n")

# =====================================================
# OUTPUT CSV
# =====================================================

csv_file = "wilayah_indonesia.csv"

with open(
    csv_file,
    "w",
    newline="",
    encoding="utf-8-sig"
) as f:

    writer = csv.writer(f)

    writer.writerow([
        "kode_wilayah",
        "nama_wilayah",
        "level",
        "parent_kode_wilayah"
    ])

    for row in records:
        writer.writerow([
            row["kode_wilayah"],
            row["nama_wilayah"],
            row["level"],
            row["parent_kode_wilayah"]
        ])

print(f"CSV berhasil dibuat: {csv_file}")

# =====================================================
# OUTPUT SQL POSTGRESQL
# =====================================================

sql_file = "wilayah_indonesia.sql"

with open(
    sql_file,
    "w",
    encoding="utf-8"
) as f:

    f.write("-- GENERATED FROM SIG BPS\n\n")

    for row in records:

        kode = escape_sql(
            row["kode_wilayah"]
        )

        nama = escape_sql(
            row["nama_wilayah"]
        )

        level = escape_sql(
            row["level"]
        )

        if row["parent_kode_wilayah"] is None:
            parent = "NULL"
        else:
            parent = (
                f"'{escape_sql(row['parent_kode_wilayah'])}'"
            )

        f.write(
            "INSERT INTO wilayah "
            "(kode_wilayah, nama_wilayah, level, parent_kode_wilayah)\n"
            f"VALUES ('{kode}', '{nama}', '{level}', {parent});\n"
        )

print(f"SQL berhasil dibuat: {sql_file}")

print("\nSELESAI")