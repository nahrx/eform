#!/usr/bin/env node
/**
 * Validator instrumen kuesioner — struktural (JSON Schema/AJV) + semantik.
 *
 *   node validate.mjs <instrumen.json> [schema.json]
 *
 * Butuh: npm i ajv ajv-formats
 *
 * Menutup tiga hal yang TIDAK bisa divalidasi JSON Schema:
 *   1. Keunikan global 'name' (dataKey jadi kolom output -> duplikat = data ketimpa).
 *   2. Resolusi referensi: optionsRef, optionsFilterBy, countFrom, skipTo, to, dan ${...}.
 *   3. Sintaks ekspresi: kurung () & ${} seimbang, dan setiap ${ref} menunjuk simpul nyata.
 */

import { readFileSync } from "node:fs";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";

const [, , instrumentPath, schemaPath = "kuesioner.schema.json"] = process.argv;
if (!instrumentPath) {
  console.error("Usage: node validate.mjs <instrumen.json> [schema.json]");
  process.exit(2);
}

const schema = JSON.parse(readFileSync(schemaPath, "utf8"));
const inst = JSON.parse(readFileSync(instrumentPath, "utf8"));

const errors = [];
const warnings = [];
const err = (path, msg) => errors.push({ path, msg });
const warn = (path, msg) => warnings.push({ path, msg });

/* ---------- 1) STRUKTURAL via AJV ---------- */
const ajv = new Ajv2020({ allErrors: true, strict: false });
addFormats(ajv);
const validate = ajv.compile(schema);
if (!validate(inst)) {
  for (const e of validate.errors) {
    const extra = e.params && Object.keys(e.params).length ? " " + JSON.stringify(e.params) : "";
    err(e.instancePath || "/", `${e.message}${extra}`);
  }
}

/* ---------- Kumpulkan simpul untuk cek semantik ---------- */
const fieldNames = new Map();       // name -> path
const containerNames = new Map();   // section/group/roster name -> path
const nameOccurrences = new Map();  // name -> [path] (deteksi duplikat)
const exprUses = [];                // { path, expr }
const refUses = [];                 // { path, kind: table|field|nav, value }

const EXPR_KEYS = ["visibleWhen", "enableWhen", "requiredWhen", "calculate"];
const RESERVED_NAV = new Set(["__end", "__next", "__prev"]);

const seen = (name, path) => {
  if (!nameOccurrences.has(name)) nameOccurrences.set(name, []);
  nameOccurrences.get(name).push(path);
};

function walkComponent(c, path) {
  if (!c || typeof c !== "object") return;

  if (c.kind === "field") {
    if (c.name) { fieldNames.set(c.name, path); seen(c.name, path); }
    for (const k of EXPR_KEYS) if (typeof c[k] === "string") exprUses.push({ path: `${path}.${k}`, expr: c[k] });
    if (c.optionsRef) refUses.push({ path: `${path}.optionsRef`, kind: "table", value: c.optionsRef });
    if (c.optionsFilterBy) refUses.push({ path: `${path}.optionsFilterBy`, kind: "field", value: c.optionsFilterBy });
    if (Array.isArray(c.validations))
      c.validations.forEach((v, i) => { if (typeof v.test === "string") exprUses.push({ path: `${path}.validations[${i}].test`, expr: v.test }); });
    if (Array.isArray(c.options))
      c.options.forEach((o, i) => { if (o.skipTo) refUses.push({ path: `${path}.options[${i}].skipTo`, kind: "nav", value: o.skipTo }); });
    if (Array.isArray(c.skips))
      c.skips.forEach((s, i) => {
        if (s.to) refUses.push({ path: `${path}.skips[${i}].to`, kind: "nav", value: s.to });
        if (typeof s.when === "string") exprUses.push({ path: `${path}.skips[${i}].when`, expr: s.when });
      });
  } else if (c.kind === "group" || c.kind === "roster") {
    if (c.name) { containerNames.set(c.name, path); seen(c.name, path); }
    if (c.kind === "roster" && c.countFrom) refUses.push({ path: `${path}.countFrom`, kind: "field", value: c.countFrom });
    if (typeof c.visibleWhen === "string") exprUses.push({ path: `${path}.visibleWhen`, expr: c.visibleWhen });
    (c.components || []).forEach((cc, i) => walkComponent(cc, `${path}.components[${i}]`));
  }
}

(inst.sections || []).forEach((s, i) => {
  const path = `sections[${i}](${s.name ?? "?"})`;
  if (s.name) { containerNames.set(s.name, path); seen(s.name, path); }
  if (typeof s.visibleWhen === "string") exprUses.push({ path: `${path}.visibleWhen`, expr: s.visibleWhen });
  (s.components || []).forEach((c, j) => walkComponent(c, `${path}.components[${j}]`));
});

(inst.validations || []).forEach((v, i) => {
  if (typeof v.test === "string") exprUses.push({ path: `validations[${i}].test`, expr: v.test });
});

/* ---------- 2) KEUNIKAN name (global) ---------- */
for (const [name, paths] of nameOccurrences)
  if (paths.length > 1) err(name, `name '${name}' dipakai ${paths.length}x: ${paths.join("  ,  ")}`);

/* ---------- 3) RESOLUSI REFERENSI ---------- */
const tables = new Set(Object.keys(inst.referenceData || {}));
const navTargets = new Set([...fieldNames.keys(), ...containerNames.keys(), ...RESERVED_NAV]);

for (const r of refUses) {
  if (r.kind === "table" && !tables.has(r.value))
    err(r.path, `optionsRef '${r.value}' tidak ada di referenceData`);
  if (r.kind === "field" && !fieldNames.has(r.value))
    err(r.path, `'${r.value}' bukan nama field yang ada`);
  if (r.kind === "nav" && !navTargets.has(r.value))
    err(r.path, `target lompatan '${r.value}' tidak ditemukan (bukan field/section/group/roster atau token __end/__next/__prev)`);
}

/* ---------- 4) SINTAKS EKSPRESI ---------- */
const stripStrings = (s) => s.replace(/'(\\.|[^'\\])*'/g, "''"); // buang literal string agar tak ganggu

for (const { path, expr } of exprUses) {
  const s = stripStrings(expr);

  // kurung () seimbang
  let depth = 0, broke = false;
  for (const ch of s) {
    if (ch === "(") depth++;
    else if (ch === ")" && --depth < 0) { broke = true; break; }
  }
  if (broke || depth !== 0) err(path, `kurung () tidak seimbang: "${expr}"`);

  // ${ } seimbang
  const open = (s.match(/\$\{/g) || []).length;
  const close = (s.match(/\}/g) || []).length;
  if (open !== close) err(path, `\${...} tidak seimbang: "${expr}"`);

  // setiap ${ref} harus resolve
  for (const m of s.matchAll(/\$\{([^}]*)\}/g)) {
    const base = m[1].trim().split(/[.\[]/)[0]; // dukung ${art.umur}, ${daftar[0]}
    if (!base || base.startsWith("__")) continue; // variabel engine: __mode, dsb.
    if (!fieldNames.has(base) && !containerNames.has(base))
      err(path, `ekspresi merujuk '${base}' yang tidak ada: "${expr}"`);
  }
}

/* ---------- 5) i18n cross-check (warning) ---------- */
const locales = new Set(inst.locales || []);
if (inst.defaultLocale && locales.size && !locales.has(inst.defaultLocale))
  err("defaultLocale", `defaultLocale '${inst.defaultLocale}' tidak ada di locales [${[...locales].join(", ")}]`);

/* ---------- LAPORAN ---------- */
if (warnings.length) {
  console.log(`\n⚠️  ${warnings.length} warning:`);
  warnings.forEach((w) => console.log(`  - [${w.path}] ${w.msg}`));
}
if (errors.length) {
  console.log(`\n❌ ${errors.length} error:`);
  errors.forEach((e) => console.log(`  - [${e.path}] ${e.msg}`));
}
const ok = errors.length === 0;
console.log(ok
  ? `\n✅ ${instrumentPath} VALID — struktural + semantik (${fieldNames.size} field, ${containerNames.size} container)`
  : `\n❌ ${instrumentPath} TIDAK VALID — ${errors.length} error`);
process.exit(ok ? 0 : 1);
