package config

import (
	"bufio"
	"crypto/rand"
	"encoding/hex"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Port          string
	DatabaseURL   string
	JWTSecret     []byte
	JWTTTL        time.Duration
	CORSOrigins   []string
	PublicBaseURL string // dipakai untuk membentuk URL share, mis. https://eform.bpskaltim.go.id
	WebDir        string // folder berisi login.html, admin.html, public.html, builder.html
	PublicDir     string // folder berisi landing page publik (index.html), disajikan di "/"
	Seed          SeedConfig
}

type SeedConfig struct {
	Username string
	Email    string
	Password string
}

func env(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func Load() *Config {
	// Muat .env (jika ada) sebelum membaca env apa pun.
	// File diabaikan kalau tidak ada; env asli OS tidak ditimpa.
	loadDotEnv(env("ENV_FILE", ".env"))

	c := &Config{
		Port:          env("PORT", "8080"),
		DatabaseURL:   env("DATABASE_URL", "postgres://postgres:postgres@localhost:5432/eform?sslmode=disable"),
		PublicBaseURL: strings.TrimRight(env("PUBLIC_BASE_URL", "http://localhost:8080"), "/"),
		WebDir:        env("WEB_DIR", "web"),
		PublicDir:     env("PUBLIC_DIR", "public"),
		Seed: SeedConfig{
			Username: env("SUPERADMIN_USERNAME", "admin"),
			Email:    env("SUPERADMIN_EMAIL", "admin@bps.go.id"),
			Password: env("SUPERADMIN_PASSWORD", "admin12345"),
		},
	}

	secret := os.Getenv("JWT_SECRET")
	if secret == "" {
		b := make([]byte, 32)
		_, _ = rand.Read(b)
		secret = hex.EncodeToString(b)
		log.Println("[WARN] JWT_SECRET kosong — memakai secret acak (token akan invalid setelah restart). Set JWT_SECRET di produksi.")
	}
	c.JWTSecret = []byte(secret)

	ttlHours := 24
	if v := os.Getenv("JWT_TTL_HOURS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			ttlHours = n
		}
	}
	c.JWTTTL = time.Duration(ttlHours) * time.Hour

	origins := env("CORS_ORIGINS", "*")
	for _, o := range strings.Split(origins, ",") {
		if o = strings.TrimSpace(o); o != "" {
			c.CORSOrigins = append(c.CORSOrigins, o)
		}
	}
	return c
}

// loadDotEnv membaca file .env sederhana dan menaruh isinya ke environment
// proses. Aturan: baris kosong / diawali '#' dilewati; prefix "export "
// diabaikan; nilai boleh dikutip ("..." atau '...'); komentar inline
// (spasi lalu '#') pada nilai tak-berkutip dipangkas; variabel yang SUDAH
// ada di environment OS TIDAK ditimpa.
func loadDotEnv(path string) {
	f, err := os.Open(path)
	if err != nil {
		return // tidak ada .env → diam saja
	}
	defer f.Close()

	sc := bufio.NewScanner(f)
	n := 0
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		line = strings.TrimPrefix(line, "export ")
		eq := strings.IndexByte(line, '=')
		if eq < 0 {
			continue
		}
		key := strings.TrimSpace(line[:eq])
		if key == "" {
			continue
		}
		if _, exists := os.LookupEnv(key); exists {
			continue // jangan timpa env asli
		}
		if err := os.Setenv(key, parseEnvValue(line[eq+1:])); err == nil {
			n++
		}
	}
	if n > 0 {
		log.Printf("[config] memuat %d variabel dari %s", n, path)
	}
}

func parseEnvValue(raw string) string {
	raw = strings.TrimSpace(raw)
	if len(raw) >= 1 && (raw[0] == '"' || raw[0] == '\'') {
		q := raw[0]
		if j := strings.IndexByte(raw[1:], q); j >= 0 {
			v := raw[1 : 1+j]
			if q == '"' {
				v = strings.ReplaceAll(v, `\n`, "\n")
				v = strings.ReplaceAll(v, `\t`, "\t")
			}
			return v
		}
		return raw[1:] // kutip tak tertutup → ambil sisanya
	}
	// tak berkutip: pangkas komentar inline (spasi/tab lalu '#')
	for i := 1; i < len(raw); i++ {
		if raw[i] == '#' && (raw[i-1] == ' ' || raw[i-1] == '\t') {
			raw = raw[:i]
			break
		}
	}
	return strings.TrimSpace(raw)
}
