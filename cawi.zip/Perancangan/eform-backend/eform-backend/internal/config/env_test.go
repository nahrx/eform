package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestParseEnvValue(t *testing.T) {
	cases := map[string]string{
		`8080`:                    `8080`,
		`8080   # default 8080`:   `8080`,        // komentar inline dipangkas
		`"hello world"`:           `hello world`, // kutip ganda
		`'single quoted'`:         `single quoted`,
		`postgres://u:p@h/db?x=1`: `postgres://u:p@h/db?x=1`, // '=' di nilai aman
		`pa#ss`:                   `pa#ss`,                   // '#' tanpa spasi bukan komentar
		`"line\nbreak"`:           "line\nbreak",             // escape \n di kutip ganda
	}
	for in, want := range cases {
		if got := parseEnvValue(in); got != want {
			t.Errorf("parseEnvValue(%q) = %q; mau %q", in, got, want)
		}
	}
}

func TestLoadDotEnv(t *testing.T) {
	dir := t.TempDir()
	envFile := filepath.Join(dir, ".env")
	content := "# komentar\nPORT=9999\nPUBLIC_DIR=mypublic   # inline\nexport CORS_ORIGINS=https://a.test,https://b.test\n"
	if err := os.WriteFile(envFile, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}
	// bersihkan env yang relevan supaya .env yang menentukan
	for _, k := range []string{"PORT", "PUBLIC_DIR", "CORS_ORIGINS", "ENV_FILE"} {
		os.Unsetenv(k)
	}
	t.Setenv("ENV_FILE", envFile)

	cfg := Load()
	if cfg.Port != "9999" {
		t.Errorf("Port = %q; mau 9999", cfg.Port)
	}
	if cfg.PublicDir != "mypublic" {
		t.Errorf("PublicDir = %q; mau mypublic", cfg.PublicDir)
	}
	if len(cfg.CORSOrigins) != 2 || cfg.CORSOrigins[0] != "https://a.test" {
		t.Errorf("CORSOrigins = %v; mau [https://a.test https://b.test]", cfg.CORSOrigins)
	}
}

func TestOSEnvWinsOverDotEnv(t *testing.T) {
	dir := t.TempDir()
	envFile := filepath.Join(dir, ".env")
	os.WriteFile(envFile, []byte("PORT=9999\n"), 0o600)
	t.Setenv("ENV_FILE", envFile)
	t.Setenv("PORT", "7777") // env OS harus menang

	if cfg := Load(); cfg.Port != "7777" {
		t.Errorf("Port = %q; mau 7777 (env OS menang)", cfg.Port)
	}
}
