/* eForm Builder ↔ backend bridge.
   Disuntikkan ke builder.html. Memakai fungsi global builder: serialize() & importJSON(). */
(function () {
  var TOKEN = localStorage.getItem("eform_token");
  if (!TOKEN) { location.replace("/login"); return; }

  var H = { "Authorization": "Bearer " + TOKEN, "Content-Type": "application/json" };
  var currentId = new URLSearchParams(location.search).get("id");

  function api(path, opts) {
    opts = opts || {};
    opts.headers = Object.assign({}, H, opts.headers || {});
    return fetch(path, opts).then(function (r) {
      if (r.status === 401) { localStorage.removeItem("eform_token"); location.replace("/login"); throw new Error("sesi habis"); }
      var ct = r.headers.get("content-type") || "";
      var p = ct.indexOf("json") >= 0 ? r.json() : Promise.resolve(null);
      return p.then(function (data) {
        if (!r.ok) throw new Error((data && data.error) || ("HTTP " + r.status));
        return data;
      });
    });
  }

  function titleOf(inst) {
    var t = inst && inst.title;
    if (!t) return "Kuesioner Tanpa Judul";
    if (typeof t === "string") return t;
    for (var k in t) if (t[k]) return t[k];
    return "Kuesioner Tanpa Judul";
  }

  // ---------- toolbar ----------
  var bar = document.createElement("div");
  bar.id = "eform-bridge-bar";
  bar.innerHTML =
    '<span id="ebb-name">Kuesioner baru</span>' +
    '<button data-a="save">💾 Simpan</button>' +
    '<button data-a="open">📂 Buka</button>' +
    '<button data-a="share">🔗 Bagikan</button>' +
    '<a href="/admin">⬅ Admin</a>' +
    '<button data-a="logout">Keluar</button>' +
    '<span id="ebb-toast"></span>';
  var css = document.createElement("style");
  css.textContent =
    "#eform-bridge-bar{position:fixed;top:8px;right:10px;z-index:99999;display:flex;gap:6px;align-items:center;" +
    "background:rgba(15,23,42,.92);color:#fff;padding:6px 8px;border-radius:10px;font:600 12px system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.3)}" +
    "#eform-bridge-bar button,#eform-bridge-bar a{background:#1e293b;color:#fff;border:none;border-radius:7px;padding:6px 10px;font:inherit;cursor:pointer;text-decoration:none}" +
    "#eform-bridge-bar button[data-a=save]{background:#0e7490}" +
    "#eform-bridge-bar button:hover,#eform-bridge-bar a:hover{filter:brightness(1.15)}" +
    "#ebb-name{max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.85}" +
    "#ebb-toast{font-weight:500;opacity:.9}";
  document.head.appendChild(css);
  document.addEventListener("DOMContentLoaded", function () { document.body.appendChild(bar); boot(); });

  function toast(msg, err) {
    var t = document.getElementById("ebb-toast");
    t.textContent = (err ? "⚠ " : "✓ ") + msg;
    t.style.color = err ? "#fca5a5" : "#86efac";
    setTimeout(function () { t.textContent = ""; }, 3500);
  }
  function setName(n) { document.getElementById("ebb-name").textContent = n; }

  bar.addEventListener("click", function (e) {
    var a = e.target.getAttribute("data-a"); if (!a) return;
    if (a === "save") doSave();
    else if (a === "open") doOpen();
    else if (a === "share") doShare();
    else if (a === "logout") { localStorage.removeItem("eform_token"); localStorage.removeItem("eform_user"); location.replace("/login"); }
  });

  function boot() {
    if (!currentId) return;
    api("/api/forms/" + currentId).then(function (f) {
      if (f.schema && typeof importJSON === "function") importJSON(f.schema);
      setName(f.title);
    }).catch(function (e) { toast(e.message, true); });
  }

  function doSave() {
    if (typeof serialize !== "function") { toast("fungsi builder tak ditemukan", true); return; }
    var inst = serialize();
    var body = JSON.stringify({ title: titleOf(inst), description: (inst.description && (inst.description.id || inst.description)) || "", schema: inst, version: inst.version || "1.0.0" });
    var req = currentId
      ? api("/api/forms/" + currentId, { method: "PUT", body: body })
      : api("/api/forms", { method: "POST", body: body });
    req.then(function (f) {
      currentId = f.id; setName(f.title);
      history.replaceState(null, "", "/builder?id=" + f.id);
      toast("Tersimpan");
    }).catch(function (e) { toast(e.message, true); });
  }

  function doOpen() {
    api("/api/forms").then(function (d) {
      var list = (d.forms || []).map(function (f) { return f.id + "|" + f.title + " (" + f.status + ")"; });
      if (!list.length) { toast("belum ada kuesioner tersimpan", true); return; }
      var pick = prompt("Buka kuesioner — ketik nomor:\n\n" + list.map(function (s, i) { return (i + 1) + ". " + s.split("|")[1]; }).join("\n"));
      var idx = parseInt(pick, 10) - 1;
      if (idx >= 0 && idx < list.length) location.href = "/builder?id=" + list[idx].split("|")[0];
    }).catch(function (e) { toast(e.message, true); });
  }

  function doShare() {
    function makeShare() {
      api("/api/forms/" + currentId + "/shares", { method: "POST", body: JSON.stringify({ allowResponses: true }) })
        .then(function (s) {
          prompt("Tautan publik (salin):\n\nPastikan kuesioner sudah dipublikasikan dari halaman Admin.", s.shareUrl);
        }).catch(function (e) { toast(e.message, true); });
    }
    if (!currentId) { toast("simpan dulu sebelum membagikan", true); return; }
    makeShare();
  }
})();
