package httpapi

import (
	"encoding/json"
	"errors"
	"net/http"
	"time"

	"github.com/bpskaltim/eform-backend/internal/auth"
	"github.com/bpskaltim/eform-backend/internal/store"
)

// resolveShare memvalidasi token: aktif, belum kedaluwarsa, dan (jika perlu) password cocok.
func (s *Server) resolveShare(w http.ResponseWriter, r *http.Request) (formID, shareID string, allowResponses bool, ok bool) {
	token := r.PathValue("token")
	sh, err := s.st.GetShareByToken(r.Context(), token)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "tautan tidak ditemukan")
		return "", "", false, false
	}
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "kesalahan server")
		return "", "", false, false
	}
	if !sh.IsActive {
		writeErr(w, http.StatusGone, "tautan sudah dinonaktifkan")
		return "", "", false, false
	}
	if sh.ExpiresAt != nil && time.Now().After(*sh.ExpiresAt) {
		writeErr(w, http.StatusGone, "tautan sudah kedaluwarsa")
		return "", "", false, false
	}
	if sh.PasswordHash != nil {
		pw := r.Header.Get("X-Share-Password")
		if pw == "" {
			pw = r.URL.Query().Get("password")
		}
		if !auth.CheckPassword(*sh.PasswordHash, pw) {
			writeErr(w, http.StatusUnauthorized, "password tautan salah")
			return "", "", false, false
		}
	}
	return sh.FormID, sh.ID, sh.AllowResponses, true
}

// GET /api/public/forms/{token} — akses skema kuesioner secara publik.
func (s *Server) publicGetForm(w http.ResponseWriter, r *http.Request) {
	formID, shareID, allowResponses, ok := s.resolveShare(w, r)
	if !ok {
		return
	}
	f, err := s.st.GetForm(r.Context(), formID)
	if err != nil {
		writeErr(w, http.StatusNotFound, "kuesioner tidak ditemukan")
		return
	}
	if f.Status != "published" {
		writeErr(w, http.StatusForbidden, "kuesioner belum dipublikasikan")
		return
	}
	s.st.IncrementShareView(r.Context(), shareID)
	writeJSON(w, http.StatusOK, map[string]any{
		"id":             f.ID,
		"title":          f.Title,
		"description":    f.Description,
		"version":        f.Version,
		"schema":         f.Schema,
		"allowResponses": allowResponses,
	})
}

// POST /api/public/forms/{token}/responses — kirim jawaban dari publik.
func (s *Server) publicSubmit(w http.ResponseWriter, r *http.Request) {
	formID, shareID, allowResponses, ok := s.resolveShare(w, r)
	if !ok {
		return
	}
	if !allowResponses {
		writeErr(w, http.StatusForbidden, "tautan ini tidak menerima jawaban")
		return
	}
	var in struct {
		Answers json.RawMessage `json:"answers"`
	}
	if err := decodeJSON(r, &in); err != nil || len(in.Answers) == 0 {
		writeErr(w, http.StatusBadRequest, "jawaban kosong atau format salah")
		return
	}
	meta := map[string]any{
		"ip":         clientIP(r),
		"userAgent":  r.UserAgent(),
		"receivedAt": time.Now().Format(time.RFC3339),
	}
	metaJSON, _ := json.Marshal(meta)
	sid := shareID
	resp, err := s.st.CreateResponse(r.Context(), formID, &sid, in.Answers, metaJSON)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "gagal menyimpan jawaban")
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"id": resp.ID, "submittedAt": resp.SubmittedAt})
}

func clientIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		return xff
	}
	return r.RemoteAddr
}
