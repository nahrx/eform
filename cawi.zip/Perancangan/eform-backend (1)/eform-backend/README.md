# eForm Backend

Backend API untuk **eForm – Builder** (alat penyusun kuesioner drag-and-drop, SE2026). Ditulis dengan Go (stdlib `net/http` + pgx), PostgreSQL, dan JWT. Menyediakan:

- **Login wajib** untuk mengakses builder dan panel admin.
- **Superadmin** dibuat otomatis saat pertama jalan (tabel users kosong).
- **Manajemen instrumen** (kuesioner): simpan skema JSON, daftar, ubah, publish.
- **Sistem share publik**: instrumen yang sudah *published* bisa dibuka tanpa login lewat token `/f/{token}`, dengan opsi password & kedaluwarsa.
- **Submisi respons publik** untuk instrumen yang share-nya mengizinkan.

---

## Prasyarat

- **Go 1.23+**
- **PostgreSQL 13+** (butuh `gen_random_uuid()` yang sudah ada di core PG13)

## Setup cepat

```bash
# 1. siapkan database
createdb -U postgres eform

# 2. konfigurasi
cp .env.example .env        # lalu sesuaikan, minimal JWT_SECRET utk produksi
# .env dimuat OTOMATIS saat start (env asli OS tetap diutamakan).
# Override path file: ENV_FILE=/path/ke/.env

# 3. dependensi & jalankan
go mod tidy
make run          # = go build + ./bin/eform-backend
# atau: make dev  (go run, tanpa artifact)
```

Migrasi dijalankan **otomatis** saat start (folder `migrations/` ter-embed ke binary). Tidak perlu tool migrasi eksternal.

Saat pertama jalan, jika tabel `users` kosong, superadmin dibuat dan kredensialnya dicetak ke log:

```
============================================================
 SUPER ADMIN dibuat (login pertama):
   username : admin
   password : admin12345
 >> GANTI password ini segera, dan set SUPERADMIN_PASSWORD di .env
============================================================
```

> Default dari `.env.example`: **admin / admin12345**. Ganti `SUPERADMIN_*` sebelum start pertama bila ingin kredensial lain, dan ganti password setelah login.

## Konfigurasi (env)

File `.env` di direktori kerja dimuat otomatis saat start (via `joho/godotenv`). Variabel yang sudah ada di environment OS **tidak ditimpa** (env asli menang). Path file bisa diubah lewat `ENV_FILE`.

| Variabel | Default | Keterangan |
|---|---|---|
| `PORT` | `8080` | Port HTTP |
| `DATABASE_URL` | `postgres://postgres:postgres@localhost:5432/eform?sslmode=disable` | DSN PostgreSQL |
| `JWT_SECRET` | *(acak bila kosong)* | **Wajib di produksi.** Kalau kosong, token invalid tiap restart |
| `JWT_TTL_HOURS` | `24` | Masa berlaku token (jam) |
| `CORS_ORIGINS` | `*` | Daftar origin dipisah koma, atau `*` |
| `PUBLIC_BASE_URL` | `http://localhost:8080` | Dasar URL share `/f/{token}` |
| `WEB_DIR` | `web` | Folder file aplikasi (login/admin/builder/public.html) |
| `PUBLIC_DIR` | `public` | Folder landing page publik (`index.html`) yang disajikan di `/` |
| `SUPERADMIN_USERNAME` | `admin` | Hanya dipakai saat seeding |
| `SUPERADMIN_EMAIL` | `admin@bps.go.id` | Hanya dipakai saat seeding |
| `SUPERADMIN_PASSWORD` | `admin12345` | Hanya dipakai saat seeding |
| `ENV_FILE` | `.env` | Path file env yang dimuat saat start |

## Halaman (UI)

| URL | Isi |
|---|---|
| `/` | **Landing page publik** dari `public/index.html` (portal + buka kuesioner via token) |
| `/login` | Form login → simpan token di localStorage → ke `/admin` |
| `/admin` | Dashboard: daftar instrumen, status, jumlah respons, publish, share, export CSV |
| `/builder` | eForm Builder (versi ter-host, ada toolbar Simpan/Buka/Bagikan). `?id=` membuka instrumen tertentu |
| `/f/{token}` | Renderer publik untuk mengisi kuesioner via token share |

> Catatan jujur: `/f/{token}` adalah **renderer dasar** (manual/inline/API option, markdown). Mesin ekspresi penuh (`visibleWhen`, validasi live, roster kompleks) ada di **preview builder**, belum di renderer publik. Untuk lapangan, idealnya output diserahkan ke renderer produksi / konverter FASIH–FormGear.

## Alur kerja

1. **Login** di `/login` sebagai superadmin.
2. **Buat instrumen** dari `/admin` → buka `/builder`, susun kuesioner, **Simpan**.
3. **Publish** instrumen dari `/admin` (status `draft → published`).
4. **Bagikan**: buat share link (opsional password & tanggal kedaluwarsa). Dapat `shareUrl` = `PUBLIC_BASE_URL/f/{token}`.
5. **Responden** membuka `/f/{token}`, mengisi, submit. Respons tersimpan dan bisa **diexport CSV** dari `/admin`.

## Endpoint API

Header auth: `Authorization: Bearer <token>`. Endpoint publik tidak butuh auth (cukup token share di path; password share lewat header `X-Share-Password` atau query `?password=`).

### Auth
| Method | Path | Auth | Keterangan |
|---|---|---|---|
| `POST` | `/api/auth/login` | — | `{username,password}` → `{token,user}` |
| `GET` | `/api/auth/me` | ✓ | Info user dari token |

### Users (superadmin)
| Method | Path | Auth | Keterangan |
|---|---|---|---|
| `GET` | `/api/users` | superadmin | Daftar user |
| `POST` | `/api/users` | superadmin | Buat user (`role`: superadmin/admin/editor, password ≥ 6) |

### Instrumen (kuesioner)
| Method | Path | Auth | Keterangan |
|---|---|---|---|
| `GET` | `/api/forms` | ✓ | Daftar instrumen (tanpa skema) |
| `POST` | `/api/forms` | ✓ | Buat instrumen (`{title,description,schema}`) |
| `GET` | `/api/forms/{id}` | ✓ | Ambil instrumen + skema |
| `PUT` | `/api/forms/{id}` | ✓ | Ubah instrumen |
| `DELETE` | `/api/forms/{id}` | ✓ | Hapus instrumen |
| `POST` | `/api/forms/{id}/publish` | ✓ | `{status}` (default `published`) |

### Share
| Method | Path | Auth | Keterangan |
|---|---|---|---|
| `POST` | `/api/forms/{id}/shares` | ✓ | Buat share (`{label,password?,expiresAt?,allowResponses?}`) → `shareUrl`, `apiUrl` |
| `GET` | `/api/forms/{id}/shares` | ✓ | Daftar share suatu instrumen |
| `DELETE` | `/api/shares/{id}` | ✓ | Cabut share (soft, `is_active=false`) |

### Respons
| Method | Path | Auth | Keterangan |
|---|---|---|---|
| `GET` | `/api/forms/{id}/responses` | ✓ | Daftar respons |
| `GET` | `/api/forms/{id}/responses.csv` | ✓ | Export CSV (union semua key jawaban) |

### Publik (tanpa login)
| Method | Path | Auth | Keterangan |
|---|---|---|---|
| `GET` | `/api/public/forms/{token}` | token share | Skema instrumen *published* + naikkan view count |
| `POST` | `/api/public/forms/{token}/responses` | token share | Submit jawaban (kalau `allowResponses`) |

### Lain
| Method | Path | Keterangan |
|---|---|---|
| `GET` | `/healthz` | Health check |

## Skema basis data

`migrations/0001_init.up.sql`:

- **users** — id (uuid), username (unik), email (unik, nullable), password_hash, role (`superadmin`/`admin`/`editor`), is_active, timestamps.
- **forms** — id, slug (unik), title, description, schema (jsonb), status (`draft`/`published`/`archived`), version, owner_id → users (SET NULL), timestamps.
- **form_shares** — id, form_id → forms (CASCADE), token (unik), label, is_active, allow_responses, password_hash (nullable), expires_at (nullable), view_count, created_by, created_at.
- **form_responses** — id, form_id (CASCADE), share_id → form_shares (SET NULL), answers (jsonb), meta (jsonb: ip/userAgent/receivedAt), submitted_at.

## Struktur project

```
eform-backend/
├── main.go                     # entrypoint: load cfg, connect, migrate, seed, serve
├── migrations/                 # SQL + embed.go (//go:embed *.sql)
├── internal/
│   ├── config/                 # env loader (joho/godotenv)
│   ├── models/                 # struct domain
│   ├── auth/                   # bcrypt + JWT HS256
│   ├── db/                     # pgxpool + migrator
│   ├── store/                  # query layer (CRUD)
│   └── httpapi/                # server, middleware, handlers, router
├── web/                        # halaman app — HTML + CSS + JS terpisah:
│                               #   login.{html,css,js}, admin.{html,css,js},
│                               #   builder.{html,css,js} + builder-bridge.js, public.html
└── public/                     # landing page publik (index.html), disajikan di "/"
```

## Catatan keamanan & batasan

- **Ganti `JWT_SECRET` & password superadmin** sebelum produksi.
- Otorisasi saat ini: editor/admin **melihat semua instrumen** (belum per-owner). Perketat bila perlu.
- Endpoint publik **belum** ada rate limiting; pertimbangkan reverse proxy (mis. Cloudflare/nginx) untuk throttling.
- Submisi publik **belum** divalidasi terhadap skema di sisi server.
- **CORS** untuk fitur lookup API di builder: server API tujuan harus mengizinkan origin, atau pakai proxy.
